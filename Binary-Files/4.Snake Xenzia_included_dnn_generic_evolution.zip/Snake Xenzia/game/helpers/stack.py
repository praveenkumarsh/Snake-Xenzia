# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 00:25:03 2019

@author: Praveen
"""

class Stack:

    def __init__(self, initial_values):
        self.stack = initial_values

    def pop(self):
        if self.is_empty():
            return None
        else:
            return self.stack.pop()

    def push(self, val):
        return self.stack.append(val)

    def peak(self):
        if self.is_empty():
            return None
        else:
            return self.stack[-1]

    def size(self):
        return len(self.stack)

    def is_empty(self):
        return self.size() == 0