# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 00:23:02 2019

@author: Praveen
"""

class Run:

    def __init__(self, action, score):
        self.action = action
        self.score = score
