# -*- coding: utf-8 -*-
"""
Created on Sat Dec 21 23:42:55 2019

@author: Praveen
"""

class Color():
    black = (0, 0, 0)
    red = (255, 0, 0)
    green = (0, 150, 0)
    white = (255, 255, 255)
    gray = (211, 211, 211)
    darkred = (207,57,30)
    blue = (20,73,239)